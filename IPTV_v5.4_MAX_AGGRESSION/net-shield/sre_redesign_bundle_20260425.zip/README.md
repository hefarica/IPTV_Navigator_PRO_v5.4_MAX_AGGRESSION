# NET SHIELD SRE Redesign Bundle — 2026-04-25 16:07 UTC

Bundle completo del despliegue SRE redesign en VPS Hetzner 178.156.147.234.

## Contenido

```
sre_redesign_bundle_20260425/
├── README.md                           ← este archivo
├── vps/                                ← ESTADO REAL EN PRODUCCIÓN (source of truth)
│   ├── etc-nginx-lua/
│   │   ├── upstream_gate.lua           ← Lua access_by_lua: pre-fetch cooldown gate
│   │   └── upstream_response.lua       ← Lua header_filter: state machine v3 con skip cache
│   ├── etc-nginx-confd/
│   │   ├── iptv-shield-rate.conf       ← Hard cap: rate=10/s por upstream host
│   │   └── iptv-lua-circuit.conf       ← lua_shared_dict upstream_state 20m
│   ├── etc-nginx-snippets/
│   │   └── shield-location.conf        ← Shield location con hooks Lua + hard cap
│   ├── opt-netshield-autopilot/
│   │   └── netshield_autopilot_v2.py   ← Autopilot v2 medición + recomendación
│   └── etc-systemd-system/
│       ├── netshield-autopilot.service ← Mode=observe
│       └── netshield-autopilot.timer   ← Cada 5 min
│
├── local/                              ← Repo local (algunos gitignored)
│   ├── frontend/
│   │   └── m3u8-typed-arrays-ultimate.js  ← Pilar 5 STEALTH JS frontend
│   ├── net-shield-nginx/               ← Configs nginx + Lua
│   ├── net-shield-autopilot/           ← Autopilot script
│   ├── net-shield-docs/                ← Runbooks y especificaciones
│   └── net-shield-metrics/             ← Baseline + snapshots + checkpoint.sh
│
├── plans/
│   ├── sre-redesign-execution.md       ← Plan ejecutado este día
│   └── velvet-munching-brook.md        ← Plan medición previo
│
├── memory/                             ← Persistent memory de Claude
│   ├── MEMORY.md                       ← Índice
│   ├── reference_sre_redesign_DEPLOYED.md
│   ├── reference_autopilot_v2_DEPLOYED.md
│   ├── reference_phase35_lua_DEPLOYED.md
│   ├── reference_phase35_lua_future_spec.md
│   ├── reference_stealth_circuit_breaker_deployed.md
│   ├── feedback_phase35_doctrine.md
│   ├── feedback_planeamos_means_plan_only.md
│   ├── feedback_vanilla_rate_too_blunt.md
│   └── project_phase4_multi_vps_ha_reframed.md
│
└── runbooks/                           ← Runbooks específicos (vacío en este bundle, ver local/net-shield-docs/)
```

## Estado del sistema al momento del bundle

### Stack del shield (orden de ejecución por request)

```
auth_request /_shield_auth        ← PHP valida owner_hash
limit_req zone=hard_cap burst=50 nodelay   ← Anti-DOS only (10 r/s × upstream)
limit_conn xtream_slot 1          ← Slot del provider (max_connections=1)
access_by_lua_file upstream_gate.lua       ← Pre-fetch cooldown gate
proxy_pass → upstream IPTV
header_filter_by_lua_file upstream_response.lua  ← State machine reactiva
```

### Política Lua v3

| Status upstream | Acción |
|---|---|
| 2xx | reset state, DICTATOR retoma |
| 403 | cooldown directo 8-15 min |
| 429 | backoff exp 1→2→4→8s + jitter, 5° → cooldown 5-15 min |
| 5xx | retry corto 0.5-1.5s sin cooldown |
| 400/401/405 | trato como 429 |
| 404 / otros | NO dispara |

**Skip si**: shield_host vacío, upstream_response_time vacío/`-`, o cache `STALE`/`HIT`/`BYPASS`/`EXPIRED`.

### Calibración (basada en medición real)

- `rate=10 r/s` (5× sobre p95 real de 2 r/s)
- `burst=50 nodelay`
- `MAX_RATE` autopilot=100, MIN=10

### Modo del autopilot

`MODE=observe` — solo lee y persiste history. NO muta producción. Para promover a `active` se requieren 288 ventanas de 5min (24h) con varianza ≤20% en `rate` recomendado.

## Restauración / rollback

### Rollback completo del shield

```bash
ssh root@178.156.147.234 'cd / && tar xzf /root/backups/full_pre_redesign_20260425_155712/etc_nginx.tar.gz && systemctl restart nginx'
```

### Rollback solo Lua (mantener hard cap)

```bash
ssh root@178.156.147.234 'cp /etc/nginx/snippets/shield-location.conf.bak_pre_lua_<TS> /etc/nginx/snippets/shield-location.conf && rm /etc/nginx/conf.d/iptv-lua-circuit.conf && nginx -t && systemctl reload nginx'
```

### Re-habilitar iptv-stealth deshabilitado

```bash
ssh root@178.156.147.234 'mv /etc/nginx/sites-available/iptv-stealth.disabled_20260425_155712 /etc/nginx/sites-enabled/iptv-stealth && nginx -t && systemctl reload nginx'
```

## Verificación operativa

```bash
# Hard cap trips (debe ser raro)
ssh root@178.156.147.234 'grep -c hard_cap /var/log/nginx/shield_error.log'

# Lua circuit events
ssh root@178.156.147.234 'grep -c APE-CIRCUIT /var/log/nginx/shield_error.log'

# Estado autopilot
ssh root@178.156.147.234 'tail -1 /opt/netshield/autopilot/state/history.jsonl | python3 -m json.tool'
ssh root@178.156.147.234 'systemctl list-timers | grep netshield'
```
