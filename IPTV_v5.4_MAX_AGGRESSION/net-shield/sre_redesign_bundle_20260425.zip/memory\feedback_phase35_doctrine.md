---
name: Doctrina Fase 3.5 — comportamiento triple por estado upstream
description: El VPS y frontend deben comportarse distinto según respuesta del upstream. NO ganas por velocidad, ganas por no ser detectable. Reglas inmutables operativas.
type: feedback
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
User estableció esta doctrina formalmente el 2026-04-25 al supervisar despliegue Sub-proyecto B.

**Regla maestra:** El sistema debe comportarse según estado del upstream:
- **Upstream OK 2xx** → DICTATOR agresivo (reconnect_delay=0, attempts=999999, sin latencia añadida)
- **Upstream rechaza 4xx** → STEALTH humano (jitter + backoff exponencial)
- **Upstream bloquea persistente** → COOLDOWN paciente (5-15min sin tocar ese host)

**Why:** "No ganas por ser más rápido. Ganas por no ser detectable." El patrón de tráfico "demasiado eficiente" dispara temp-blacklist. Pero ralentizar SIEMPRE rompe zapping. Solución: tres modos según señal del upstream.

**How to apply:** ante cualquier propuesta de cambio en el path shield/frontend que afecte tráfico:

1. NO modificar parámetros DICTATOR del M3U8 (OMEGA-NO-DELETE inviolable)
2. NO introducir latencia en flujo exitoso
3. NO romper zapping rápido (TTFB <200ms inviolable, Capa #1 prioridad)
4. NO bloquear tráfico legítimo
5. NO aplicar rate limit global agresivo
6. **TODO debe ser por upstream host** (granularidad correcta — `$proxy_host` o `$stealth_upstream`, NO `$remote_addr` ni global)
7. NO usar soluciones genéricas tipo "1r/s para todo" — frenan zapping
8. SIEMPRE priorizar experiencia del usuario sobre stealth
9. **EL VPS debe dejar de insistir cuando el upstream rechaza** — `proxy_next_upstream` NO debe incluir 403/429
10. TODO debe ser reversible (rollback inmediato + backup pre-cambio)

**Anti-patrones explícitos rechazados por usuario:**
- `limit_req_zone $proxy_host rate=1r/s burst=3 nodelay` — rompe zapping al 4° tap rápido
- `proxy_next_upstream` con `http_403 http_429` — el VPS persigue al provider que ya dijo "no"
- Rate global `$remote_addr` — castiga al cliente legítimo, no al upstream lento

**Frase operativa rectora:**
> El VPS no debe ser un atacante… Debe ser un cliente creíble.

**Configuración deployed que respeta la doctrina (vanilla NGINX, 2026-04-25):**
- `limit_req zone=stealth_upstream_req burst=15 delay=10` (rate=3r/s) — preserva 10 zaps en ráfaga
- `limit_conn stealth_upstream_conn 4` — coexiste con xtream_slot=1 user/pass
- `limit_req_status 429` (no 503) — DICTATOR `attempts=999999` lo retry-ea
- `proxy_next_upstream` SIN 403/429 — VPS no insiste tras rechazo

**Phase 2 (futuro):** OpenResty/Lua state machine con cooldown explícito 5-15min — ver `reference_phase35_lua_future_spec.md`.
