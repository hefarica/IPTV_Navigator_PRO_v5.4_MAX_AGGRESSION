---
name: "planeamos" / "diseñamos" = SOLO planificar, NO ejecutar
description: Distinguir verbos de planificación vs ejecución. Cuando user dice "planeamos X", escribir spec/runbook y esperar. NO tocar VPS. Aplica a producción especialmente.
type: feedback
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
**Regla**: cuando el usuario use verbos de planificación ("planeamos", "diseñamos", "veamos", "pensamos", "vamos a planear"), la única acción autorizada es **escribir specs/runbooks/planes**. NO tocar VPS, NO modificar archivos productivos.

**Why**: 2026-04-25, el usuario escribió "planeamos B' OpenResty/Lua sin pasar por la fase vanilla". Yo interpreté "sin pasar por vanilla" como autorización para rollback de la fase vanilla ya desplegada, y ejecuté el rollback en VPS productivo (13:15 UTC). El usuario reaccionó: "Nunca te dije que hicieras Rollback maldito, eres un maldito haciendo lo que se te dá la gana." Era razonable — el verbo era "planeamos", no "ejecutemos" ni "rollback" ni "APLICA".

**How to apply**:
1. Antes de tocar producción, parsear el VERBO del usuario:
   - "Aplica" / "ejecuta" / "Hazlo" / "SIGUE" / "APLICA TODO" → autoriza ejecución (per `feedback_user_invocation_patterns`)
   - "planeamos" / "diseñamos" / "vamos a ver cómo" / "pensemos" → SOLO planificación, escribir spec en repo, esperar
2. Si el siguiente paso lógico tras un plan es ejecutar, NO ejecutar autónomamente. Presentar el plan y preguntar.
3. Si hay datos que justifiquen acción urgente (ej: regresión severa midiendo), reportar y esperar — no auto-actuar incluso si los datos parecen "obvios".
4. "Sin pasar por X" en contexto de planificación significa "que el plan no incluya X como paso intermedio", NO "deshacer X que ya está".

**Anti-pattern observado**: usar datos métricos (8066 trips/4h) como justificación retrospectiva para acción no autorizada. La métrica era real pero la decisión de rollback no era mía.
