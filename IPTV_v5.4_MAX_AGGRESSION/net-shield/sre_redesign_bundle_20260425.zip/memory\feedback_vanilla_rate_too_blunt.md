---
name: Vanilla NGINX limit_req es demasiado blunt para shield IPTV
description: Lección aprendida 2026-04-25 — limit_req sin context-awareness no funciona contra patrón TiviMate+M3U8-generator. Solo usar Lua state machine que reaccione a respuestas del upstream.
type: feedback
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
**Regla**: NO usar `limit_req` vanilla en el shield IPTV bajo ningún esquema de tunning de rate/burst. Solo Lua circuit breaker reactivo (lee status del upstream).

**Why**: 2026-04-25, deploy de `limit_req zone=stealth_upstream_req burst=15 delay=10 rate=3r/s` keyed por upstream host generó **8066 trips en 4h post-deploy** = 2000/h. El 66% del tráfico legítimo fue rechazado con 429 (todos con `ut=-`, sin tocar upstream). Causa: el patrón real de tráfico — TiviMate prefetching + segundo peer WG haciendo zapping + M3U8 generator probing — produce bursts >3r/s al MISMO upstream que son legítimos, no scraping.

**El problema arquitectónico**:
- `limit_req` cuenta requests **entrantes** sin saber si el upstream está sano o no
- Bursts humanos legítimos (zap rápido, prefetch HLS) son indistinguibles de scraping
- Tunning del rate (3, 5, 10, 15 r/s) no resuelve — siempre habrá tráfico legítimo bursty que excede
- DICTATOR `attempts=999999` enmascara el daño porque el player reintenta hasta colarse, pero defeats el propósito stealth

**How to apply**:
1. **Nunca** sugerir `limit_req` vanilla en shield IPTV. Si el usuario pide rate limit, redirigir a Lua circuit breaker.
2. La señal correcta para gatear es **status del upstream** (4xx/5xx/RST), NO rate de requests entrantes.
3. `limit_conn xtream_slot 1` (pre-existente, key user/pass) SÍ funciona porque protege contra max_connections=1 del provider Xtream — distinto problema.
4. `limit_conn $upstream_host 4` también podría servir como hard cap defense-in-depth, pero solo si Lua state machine ya está corriendo y midiendo (verificar primero que no se trip naturalmente).

**Ejemplo de scraping pattern observado en logs (causal)**:
- Peer `10.200.0.3` (segundo peer, no-ONN) hitting el mismo channel ID `1404713.m3u8` con mismo `ape_sid=9bed79683256e400` y mismo `ape_nonce=1qs4zdun2bb0` repetidamente
- Esto es probablemente probe de validación del M3U8 generator, comportamiento legítimo
- vanilla `limit_req` no puede distinguir esto de un atacante real

**Corolario doctrinal**: la ÚNICA forma vanilla NGINX de hacer stealth es vía `proxy_next_upstream` (que NO incluya 403/429) — eso ya está en `00-iptv-quantum.conf` global. Más allá de eso, requiere Lua.
