---
name: Fase 4 — Multi-VPS HA autorizado (reframed 2026-04-25)
description: Reemplaza la concepción anterior "PROXY DOMINATION / IP rotation evasion". User explicitly rechazó instruir bypass de bloqueos. Fase 4 ahora es failover técnico autorizado entre VPS, no evasión.
type: project
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
User reframó Fase 4 explícitamente el 2026-04-25.

**Why:** la doctrina original "PROXY DOMINATION" implicaba rotación de IP para saltar bloqueos del provider IPTV — esto es bypass / evasión de detección. User explicitly dijo "no te voy a dar instrucciones para evadir bloqueos de proveedores mediante rotación de IP o bypass". Pivotó a HA autorizado.

**How to apply:** cuando se hable de Fase 4 / multi-VPS / failover, asumir el modelo Multi-VPS HA NO el de evasión. Las reglas inmutables:

1. **NO rotar IP para saltar bloqueos.** Si el provider banea, NO se cambia IP para volver a entrar.
2. **Solo failover si un nodo está caído o degradado.** Falla técnica, no falla por bloqueo.
3. **NO reintentar agresivamente contra upstream que responde 403/429.** Cooldown, no persecución.
4. **En 403/429: cooldown** (delegado al circuit breaker Lua de Fase 3.5 Phase 2).
5. **En timeout/5xx: failover técnico** al siguiente VPS sano.
6. **Logs por host, status, nodo y causa** — toda decisión de failover queda trazable.

## Arquitectura propuesta (no implementada)

```
ONN 4K
  ↓
WireGuard
  ↓
VPS Gateway Principal (current 178.156.147.234)
  ↓
Health Router (decide nodo destino)
  ↓
VPS A / VPS B / VPS C (cluster)
  ↓
Upstreams autorizados (x1megaott, line.tivi, ky-tv, tivigo)
```

## Frase operativa rectora

> El VPS no debe ser un atacante… Debe ser un cliente creíble.

## Relación con `reference_net_shield_architecture.md`

Esta memoria refina las "Fases 3-4" mencionadas allá. La fase 4 anterior estaba ambigua entre HA y rotación. Ya no.
