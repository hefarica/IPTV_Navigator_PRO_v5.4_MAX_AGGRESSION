---
name: NetShield Autopilot v2 — DEPLOYED 2026-04-25 16:07 UTC en MODO observe
description: Mide p50/p95/max real upstream cada 5min, recomienda rate. Modo observe = solo lee. Promoción a active requiere 288 ventanas estables (24h).
type: reference
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
## Files en VPS

- `/opt/netshield/autopilot/netshield_autopilot_v2.py` — script principal (excluye ut=- y STALE/HIT, glob log files con rotated, cap burst≤rate×10)
- `/opt/netshield/autopilot/state/history.jsonl` — append-only history per ciclo
- `/opt/netshield/autopilot/backups/` — para futura promoción a active
- `/etc/systemd/system/netshield-autopilot.service` — ExecStart con env MODE=observe
- `/etc/systemd/system/netshield-autopilot.timer` — cada 5 min

## Modo actual

**MODE=observe** — solo lee logs y persiste history. NO escribe configs nginx, NO muta producción. Para verificar:

```bash
ssh root@178.156.147.234 'systemctl list-timers | grep netshield'
ssh root@178.156.147.234 'tail -1 /opt/netshield/autopilot/state/history.jsonl | python3 -m json.tool'
ssh root@178.156.147.234 'journalctl -u netshield-autopilot.service -n 60 --no-pager'
```

## Promoción a MODE=active (NO automático)

Requiere 288 ventanas (24h) con varianza ≤20% en `recommended.rate_rps`. Sin esa estabilidad NO aplica nada (queda armed pero idle).

Para promover:

```bash
ssh root@178.156.147.234 'sed -i s/MODE=observe/MODE=active/ /etc/systemd/system/netshield-autopilot.service && systemctl daemon-reload && systemctl restart netshield-autopilot.service'
```

## Métricas observadas en primer ciclo (16:07 UTC)

- 28121 líneas escaneadas última hora
- 27450 viejas, 507 rate-limited propios excluidos, 0 cache (interesante — log_format no marca STALE/HIT? a investigar)
- 164 events real upstream
- nfqdeuxu.x1megaott.online: p95=4.8/s max=23/s (max=23 es ruido de mis tests sintéticos)
- line.tivi-ott.net: p95=2.0 max=2
- Recomendación auto: `rate=10/s burst=50` — coincide con deployed manual

## Bugs fixed en v2 (vs v1 del postmortem)

- H6: excluir `ut=-` (rate-limited propio) y STALE/HIT/BYPASS/EXPIRED
- H8: STABILITY_WINDOWS=288 (24h × 12 ventanas/h) — coincide con doc
- H9: cap `burst ≤ rate × 10` para evitar burst que efectivamente desactiva el rate
- H10: glob `*.log*` incluye rotated + `.gz`
- BUG seek+text mode: `fh.seek(0)` para archivos <30MB (sino quedaba al final del archivo)

## Tunables (env vars del systemd unit)

| Var | Default | Significado |
|---|---|---|
| NS_AUTOPILOT_MODE | observe | observe / recommend / active |
| NS_LOG_GLOB | `/var/log/nginx/shield_access.log*` | qué leer |
| NS_WINDOW_MINUTES | 15 | ventana de cada ciclo |
| NS_MIN_RATE | 10 | piso del rate recomendado |
| NS_MAX_RATE | 100 | techo del rate recomendado |
| NS_STABILITY_WINDOWS | 288 | ventanas estables requeridas para active |

## Frequencia de ejecución

Timer dispara cada 5 min. Con WINDOW_MINUTES=15, hay overlap (cada ciclo mira últimos 15 min, dispara cada 5 min). Esto da 3 muestras por ventana, suaviza spikes momentáneos.
