---
name: Phase 3.5 Phase 2 Lua Circuit Breaker — DEPLOYED 2026-04-25
description: Lua state machine en shield NGINX. Module libnginx-mod-http-lua. Coexiste con limit_req+limit_conn vanilla y xtream_slot. Bugs 1+2 fixed in v2.
type: reference
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
Desplegado 2026-04-25 13:31 UTC, fix v2 aplicado 13:41 UTC.

## Stack actual en VPS (orden de ejecución por request)

1. `auth_request /_shield_auth` (verifica owner_hash → fastcgi PHP)
2. `access_by_lua_file /etc/nginx/lua/upstream_gate.lua` — si shield_host está en cooldown → 503 inmediato
3. `limit_conn xtream_slot 1` — slot por user/pass (pre-existente)
4. `limit_req zone=stealth_upstream_req burst=15 delay=10` (vanilla, sigue activo, key=upstream host)
5. `limit_conn stealth_upstream_conn 4` (vanilla, key=upstream host)
6. `proxy_pass http://$shield_upstream$shield_path`
7. `header_filter_by_lua_file /etc/nginx/lua/upstream_response.lua` — actualiza state según status

## Files en VPS

- `/etc/nginx/lua/upstream_gate.lua` (1907 bytes, md5 `708f278e17275d9ba8225e3ce66fb9dc`)
- `/etc/nginx/lua/upstream_response.lua` (3473 bytes, md5 `ef56eb6beb716c14d59fe35d16ebf5d9`)
- `/etc/nginx/conf.d/iptv-lua-circuit.conf` — declara `lua_shared_dict upstream_state 20m`
- `/etc/nginx/snippets/shield-location.conf` — hooks Lua inyectados tras `auth_request_set`

## Módulo

`libnginx-mod-http-lua` v0.10.26-2 (Ubuntu apt, NO OpenResty replacement)
- Auto-loads: `/etc/nginx/modules-enabled/50-mod-http-lua.conf`
- Backend: LuaJIT 2.1
- Bundled: `lua-resty-core` 0.1.28-2

## Bugs fixed en v2 (2026-04-25 13:41)

**Bug 1 — Keying incorrecto**: original `host_key()` usaba `ngx.var.proxy_host or ngx.var.host` → cuando $proxy_host vacío caía a `$host` que es siempre `iptv-ape.duckdns.org` (server_name del shield). Resultado: TODOS los upstreams compartían cooldown global. Fix: keyear por `ngx.var.shield_host` (variable seteada en location vía `set $shield_host $2;` regex capture). Skip si vacío.

**Bug 2 — State contamination por errores locales**: `header_filter_by_lua` fire incluso para responses generados localmente (auth fail 401/403, limit_req 429, etc) sin tocar upstream. Cada uno actualizaba state machine erróneamente. Fix: skip si `ngx.var.upstream_response_time` está vacío/`-`/nil → solo procesar errors REALMENTE provenientes del upstream.

## State machine current behavior (post-fix)

| Trigger | Acción | Header emitted |
|---|---|---|
| 2xx desde upstream | reset state (retry=0, cooldown=0) | `X-APE-Circuit: reset` |
| 4xx (400,401,403,405,429) o 5xx desde upstream | retry++, backoff exp 1→2→4→8s+jitter(80,400)ms | `X-APE-Circuit: backoff` + `X-APE-Retry: N` + `X-APE-Delay-Ms: N` |
| Retry > 4 | cooldown random(5,15)min, reset retry counter | `X-APE-Circuit: backoff` + delay grande |
| Request al host con cooldown activo (gate) | exit 503 sin tocar upstream | `X-APE-Circuit: cooldown` + `X-APE-Upstream: host` |
| Auth fail / limit_req / errores locales | SKIP (no contamina state) | sin header X-APE-* |

## Backups (rollback ready)

- `/root/backups/nginx_pre_lua_20260425_133047/etc_nginx.tar.gz` (full /etc/nginx pre-Lua)
- `/etc/nginx/snippets/shield-location.conf.bak_pre_lua_20260425_133147` (sin hooks Lua)

## Rollback inmediato

```bash
# Solo quitar hooks Lua, mantener vanilla:
cp /etc/nginx/snippets/shield-location.conf.bak_pre_lua_20260425_133147 \
   /etc/nginx/snippets/shield-location.conf
rm /etc/nginx/conf.d/iptv-lua-circuit.conf
nginx -t && systemctl reload nginx

# Rollback profundo (desinstalar módulo):
apt remove -y libnginx-mod-http-lua && systemctl reload nginx
```

## Estado del shared_dict tras bugs

Antes del fix existieron entries polluted con key `iptv-ape.duckdns.org` (cooldown 5-15min). Tras fix son **inertes** — el nuevo gate keya por `shield_host` y nunca consulta esa entry. Eventualmente expiran. No requiere nginx restart.

## Pendiente medir (con tráfico real ONN 4K)

- Observar logs `[APE-CIRCUIT]` con `host=tivigo.cc|nfqdeuxu...|line.tivi-ott.net|ky-tv.cc` (no más `iptv-ape.duckdns.org`)
- Validar que cooldown solo se dispara cuando upstream realmente devuelve error
- Comparar T+24h vs baseline T0 en `nginx_upstream_prem_closed` y `nginx_connect_refused` (Sentinel)
