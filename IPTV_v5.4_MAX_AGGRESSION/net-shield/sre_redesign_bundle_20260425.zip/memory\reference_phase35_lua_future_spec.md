---
name: Phase 3.5 Lua Circuit Breaker — FUTURE spec (NOT deployed)
description: OpenResty/Lua state machine por upstream host. Mirror exacto del JS Pilar 5. Hand-over user 2026-04-25, deploy condicionado a validación 24-72h fase vanilla.
type: reference
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
User entregó la spec completa Lua el 2026-04-25 con instrucción explícita "NO IMPLEMENTAR AÚN".

## Archivos guardados en repo (sin desplegar)

- `IPTV_v5.4_MAX_AGGRESSION/net-shield/nginx/lua/upstream_gate.lua` — hook `access_by_lua_file`. Si `dict:get(host..":cooldownUntil") > now` → return 503 inmediato sin tocar upstream.
- `IPTV_v5.4_MAX_AGGRESSION/net-shield/nginx/lua/upstream_response.lua` — hook `header_filter_by_lua_file`. State machine: 2xx reset, 4xx/5xx backoff exp 1→2→4→8s + jitter, 5° error cooldown random(5-15min).
- `IPTV_v5.4_MAX_AGGRESSION/net-shield/nginx/openresty-future-integration.conf` — http{} `lua_shared_dict upstream_state 20m;` + integración location.

## Pre-requisitos antes de deploy

1. Validar 24-72h fase vanilla (limit_req + limit_conn) en producción
2. Counts 403/429 desde upstream deben bajar ≥30% con vanilla solo
3. 0 trips inesperados de limit_req (shield emite <5 × 429/h propios)
4. TTFB <200ms preservado

## Cambio de proceso requerido

OpenResty REEMPLAZA nginx vanilla 1.24 actual. Implica:

- `apt remove nginx && apt install openresty` (ventana larga, restart total proceso)
- Migrar `/etc/nginx/` → `/usr/local/openresty/nginx/conf/`
- Validar todo el resto del stack (auth_request fastcgi, cache RAM, mime types, upload, php-fpm) sigue funcionando bajo OpenResty
- Riesgo: ALTO — reemplazo de proceso productivo

## Coexistencia con vanilla

Cuando se deploye Lua, MANTENER las directivas vanilla `limit_req` + `limit_conn` activas como defense-in-depth. Lua sirve cooldown profundo, vanilla sirve rate cap inmediato.

## Comportamiento resultante

- Upstream OK 2xx → header `X-APE-Circuit: reset`, state limpio, DICTATOR.
- Upstream rechaza 4xx → `state.retry++`, backoff(1→2→4→8s+jitter).
- Próxima request misma host dentro cooldown → 503 inmediato (gate previo a upstream).
- 5° error consecutivo → cooldown random(5-15min). Reset retry counter.
- Logs `[APE-CIRCUIT]` en error.log con host/status/retry/delay_ms.
- Headers debug: `X-APE-Circuit`, `X-APE-Upstream`, `X-APE-Retry`, `X-APE-Delay-Ms`.

## Riesgos a medir en staging antes de prod

- `lua_shared_dict 20m`: monitor uso, ajustar a 50m si se llena
- `math.randomseed` por worker: ok para jitter humano (no crypto)
- Race conditions get+set en dict: aceptable, peor caso = doble update, eventually consistent
