---
name: SRE Redesign DEPLOYED 2026-04-25 16:07 UTC
description: Hard cap permisivo (10r/s burst=50 nodelay) + Lua v3 reactivo + autopilot v2 observe. Reemplaza vanilla limit_req=3r/s que generaba 8066 trips/4h. Estado funcional confirmed.
type: reference
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---
Desplegado 2026-04-25, basado en redesign SRE post-postmortem. Reemplaza la fase vanilla problemática.

## Stack final del shield (orden de ejecución por request)

1. `auth_request /_shield_auth` — owner_hash via PHP
2. `limit_req zone=hard_cap burst=50 nodelay` — **Anti-DOS only, NO anti-bot**. Rate=10/s sostenido per upstream. Burst absorbe ráfagas de zapping. Solo dispara contra scraping >10/s sostenido.
3. `limit_conn xtream_slot 1` — pre-existente, key user/pass del provider
4. `access_by_lua_file upstream_gate.lua` — Lua gate: si `shield_host` en cooldown → 503 sin tocar upstream
5. `proxy_pass` al upstream IPTV
6. `header_filter_by_lua_file upstream_response.lua` — state machine reactiva al status real del upstream

**Lo eliminado** (vs versión anterior):
- `limit_req zone=stealth_upstream_req rate=3r/s burst=15 delay=10` — generaba 66% rechazo legítimo
- `limit_conn stealth_upstream_conn 4` — innecesario, Lua maneja cooldown
- `delay=10` queue — rompe TTFB perceptible

## Files en VPS

| Path | Estado |
|---|---|
| `/etc/nginx/conf.d/iptv-shield-rate.conf` | NUEVO. `map $request_uri → $shield_upstream_host` + `limit_req_zone hard_cap rate=10r/s` |
| `/etc/nginx/conf.d/iptv-stealth-rate.conf.deprecated_20260425_160229` | DEPRECATED (vanilla viejo) |
| `/etc/nginx/snippets/shield-location.conf` | MODIFICADO. Hard cap reemplazó vanilla limit_*. Lua hooks intactos. |
| `/etc/nginx/lua/upstream_gate.lua` | unchanged v2 |
| `/etc/nginx/lua/upstream_response.lua` | v3 con fix STALE/HIT skip + política diferenciada por status |
| `/etc/nginx/conf.d/iptv-lua-circuit.conf` | unchanged (`lua_shared_dict upstream_state 20m`) |
| `/etc/nginx/sites-enabled/iptv-stealth` | ELIMINADO (era config muerta, conflicting server_name) |
| `/etc/nginx/sites-available/iptv-stealth.disabled_20260425_155712` | preservado, reversible con mv |

## Backup completo pre-redesign

`/root/backups/full_pre_redesign_20260425_155712/etc_nginx.tar.gz` (SHA `54d758c31e9dec2d`)

## Rollback completo (1 comando)

```bash
ssh root@178.156.147.234 'cd / && tar xzf /root/backups/full_pre_redesign_20260425_155712/etc_nginx.tar.gz && systemctl restart nginx'
```

## Política Lua v3 (upstream_response.lua)

| Status upstream | Acción Lua |
|---|---|
| 2xx | reset state, DICTATOR retoma |
| 403 | cooldown directo 8-15 min (provider rechazo persistente) |
| 429 | backoff exp 1→2→4→8s + jitter, 5° → cooldown 5-15 min |
| 5xx (500/502/503/504) | retry corto 0.5-1.5s sin cooldown (transitorio) |
| 400/401/405 | trato como 429 |
| 404 / otros | NO dispara (path-not-found no es signal de ban) |

**Skip si**: shield_host vacío, upstream_response_time vacío/`-` (no hubo proxy_pass), o cache `STALE`/`HIT`/`BYPASS`/`EXPIRED`.

## Calibración rate=10 burst=50 nodelay

Justificación basada en medición Fase A (15:57 UTC, ventana 1h):
- p95 global = 2 r/s, max = 3 r/s real
- 79% del tráfico previo era rate-limited por vanilla 3r/s (8066 trips/4h confirmados)
- rate=10 = 5× sobre p95 real, no toca tráfico humano normal
- burst=50 nodelay absorbe ráfagas zapping sin queue
- Solo dispara contra scraping sostenido >10/s al MISMO upstream

## Smoke test post-deploy validado

Test 60 requests paralelas a un upstream:
- ~50 pasaron (burst=50)
- 7 × 429 hard_cap (excedente)
- 8 × 503 con `[APE-CIRCUIT] host=nfqdeuxu.x1megaott.online status=503 retry=1-3 delay_ms=686-1290 cs=MISS`
- ✓ Lua keying correcto
- ✓ Skip cache hits funciona
- ✓ Política diferenciada 5xx (retry corto) confirmada empíricamente

## Verificación operativa

```bash
# Hard cap trips (debe ser raro, <50/h)
grep -c 'hard_cap' /var/log/nginx/shield_error.log

# Lua circuit events
grep -c 'APE-CIRCUIT' /var/log/nginx/shield_error.log

# State actual del Lua dict (para introspección)
# (endpoint /_lua_dump diferido — autopilot da visibility por log analysis)
```
