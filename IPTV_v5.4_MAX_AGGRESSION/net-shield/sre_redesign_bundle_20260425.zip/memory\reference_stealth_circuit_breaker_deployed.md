---
name: Stealth Circuit Breaker vanilla (Fase 3.5 Capa 4) — ROLLED BACK 2026-04-25
description: HISTORIA. Vanilla limit_req 3r/s burst=15 delay=10 generó 8066 trips/4h (66% rechazo). Rollback 2026-04-25 13:15 UTC. Pivote a OpenResty/Lua Phase 2.
type: reference
originSessionId: 76c7c453-74cd-46b7-b854-bd741a626a8c
---

## Estado actual: ROLLED BACK 2026-04-25 13:15 UTC

Vanilla NGINX rate governance demostró ser demasiado blunt para el patrón real (TiviMate + 2do peer + M3U8 generator hacen bursts naturales >3r/s al mismo upstream). 8066 trips en 4h = 2000/h, 100× sobre threshold de rollback de 20/h. Pivote a Lua phase 2 — runbook en `IPTV_v5.4_MAX_AGGRESSION/net-shield/docs/RUNBOOK_PHASE2_LUA_CIRCUIT_BREAKER.md`.

## Backups del rollback en VPS

- `/etc/nginx/snippets/shield-location.conf.bak_pre_rollback_20260425_131515` — pre-rollback
- `/etc/nginx/conf.d/iptv-stealth-rate.conf.removed_20260425_131515` — config completa zone+conn (renamed, no eliminado, por si se necesita referencia)

## Histórico (deploy 2026-04-25 08:45 → rollback 13:15 UTC, 4h vida)

## Archivos en VPS

- `/etc/nginx/conf.d/iptv-stealth-rate.conf` — NUEVO. Tiene:
  - `map $request_uri → $stealth_upstream` (extrae host del path `/shield/{owner}/{host}/...`)
  - `limit_req_zone $stealth_upstream zone=stealth_upstream_req:10m rate=3r/s`
  - `limit_conn_zone $stealth_upstream zone=stealth_upstream_conn:10m`
- `/etc/nginx/snippets/shield-location.conf` — MODIFICADO. Bloque añadido tras `limit_conn xtream_slot 1`:
  - `limit_req zone=stealth_upstream_req burst=15 delay=10` + `limit_req_status 429`
  - `limit_conn stealth_upstream_conn 4`
  - Backup: `shield-location.conf.bak_pre_stealthcb_20260425_084528` y `.bak_pre_limitconn_20260425_085603`

## Coexistencia

- `limit_conn xtream_slot 1` (key `$xtream_account` user/pass) sigue activo INTACTO. NO se reemplazó.
- `proxy_next_upstream` global en `00-iptv-quantum.conf` sin tocar.
- `proxy_buffering on`, `proxy_cache_lock`, cache 4xx=0 todo intacto.

## Config exacta (calibración zapping-safe)

```
rate=3r/s burst=15 delay=10 limit_req_status=429
```

- 10 zaps en ráfaga al mismo upstream → instant (no delay)
- Zaps 11-15 → encolados al rate (333ms apart)
- >15 → 429 (cliente lo retry-ea por DICTATOR `attempts=999999`)

## Backup completo pre-cambio

`/root/backups/nginx_pre_stealthcb_20260425_084440/` con `etc_nginx.tar.gz` SHA `63247c6105e18147...`, iptables-save, nginx_dashT_full_dump, nginx_status.

## Rollback inmediato

```bash
ssh root@178.156.147.234 'rm -f /etc/nginx/conf.d/iptv-stealth-rate.conf && \
  cp /etc/nginx/snippets/shield-location.conf.bak_pre_stealthcb_20260425_084528 /etc/nginx/snippets/shield-location.conf && \
  nginx -t && systemctl reload nginx'
```

## Verificación post-deploy (08:47 UTC)

- nginx active, 5 workers respawned cleanly
- 0 limit_req trips en error log
- 0 nuevos 429 emitidos por mi rate (los 429 visibles en tail eran pre-reload, del xtream_slot)
- Load avg 0.26 (sin impacto)
- TTFB curl test <0.5ms
- 2 peers WG cursando (ONN 4K 69.7GB TX)

## Tunables — subir/bajar según métricas 24h

| Param | Inicial | Subir si | Bajar si |
|---|---|---|---|
| rate | 3r/s | zapping mismo upstream se traba | 403/429 from upstream NO bajan |
| burst | 15 | shield emite >5 × 429/h propios | (poco impacto) |
| delay | 10 | zapping perceptiblemente lento | (poco impacto) |

## Pendiente (futuro Sub-proyecto B')

NGINX vanilla 1.24 sin Lua. Para state machine real (cooldown 5–15min por upstream tras N errores 4xx) se requiere instalar OpenResty. Runbook separado, ventana propia.
