# Plan — SRE Redesign Execution (Fase A + B + C completo)

## Context

Tras postmortem y revisión SRE: vanilla `limit_req rate=3r/s burst=15 delay=10` es demasiado blunt (8066 trips/4h, 66% rechazo legítimo), y vive en `preaccess` phase impidiendo que Lua circuit breaker `access_by_lua` vea el tráfico rechazado. Lua además tiene fix incompleto (no skip de cache STALE/HIT).

Plan ejecuta el rediseño completo: hard cap permisivo (anti-DOS) + Lua reactivo (anti-bot) + autopilot observe que mide y recomienda.

User aprobó 6 concerns: full restart 3-5s OK, rate calibrado por medición real, eliminar iptv-stealth muerto reversiblemente, lua_shared_dict resetea en restart, autopilot solo observe (no muta autónomo), verificar quién hizo restart 14:45 antes de tocar.

## Estado actual VPS (178.156.147.234)

- nginx 1.24 vanilla + libnginx-mod-http-lua v0.10.26 instalado
- shield-location.conf tiene: vanilla limit_req+limit_conn (re-aplicado 13:30) + Lua hooks (deployed 13:31, fix v2 13:41)
- Master process restartó 14:45 UTC (origen no confirmado — Fase 0 lo audita)
- Lua silente post-restart (causa raíz no confirmada — sospechosa: cache de bytecode pre-restart)
- Backups múltiples disponibles en `/root/backups/` y `/etc/nginx/snippets/*.bak_*`

## Fase 0 — Audit estado pre-cambio (read-only, ~2 min)

1. Confirmar nginx healthy (`systemctl is-active`, workers count, load)
2. Auditar quién restartó a 14:45:
   - `journalctl -u nginx --since "14:30" --until "15:00"`
   - `apt log` por unattended-upgrade reciente
   - `last reboot` para descartar reboot completo
3. Confirmar Lua module aún cargado: `nginx -T | grep load_module.*lua`
4. Confirmar vanilla limit_req aún activo: `nginx -T | grep stealth_upstream`

**Criterio go/no-go**: si origen del restart era unattended-upgrade o conocido → OK. Si origen desconocido → STOP, investigar antes de continuar.

## Fase A — Cleanup + medición (~5 min, 1 cambio reversible)

1. **Backup completo** `/etc/nginx` + `nginx -T` dump → `/root/backups/full_pre_redesign_<TS>/`
2. **Eliminar config muerta H2**: `mv /etc/nginx/sites-enabled/iptv-stealth → sites-available/iptv-stealth.disabled` (reversible con mv inverso)
3. **Medición baseline excluyendo ruido propio**:
   - awk sobre `shield_access.log` última 1h
   - **EXCLUIR**: requests con `ut=-` (rate-limited propio) y `STALE`/`HIT` (cache, no upstream real)
   - Calcular p50/p95/max req/s por upstream host
4. **Calcular rate recomendado**: `rate = ceil(p95_global × 1.5)`, clamp [10, 100]
5. **Reportar números** antes de Fase B → confirmar si rate calculado tiene sentido

**Criterio go/no-go**: si p95 < 1 r/s (tráfico muy bajo) → recomendado=10 (mínimo). Si p95 > 50 → revisar manualmente, puede haber anomalía.

## Fase B — Redesign deployment (~10 min activo, 3-5s downtime)

### B.1 Preparar archivos locales

1. Escribir `net-shield/nginx/lua/upstream_gate.lua` v3 (sin cambios vs v2, ya correcto)
2. Escribir `net-shield/nginx/lua/upstream_response.lua` v3 con:
   - Skip cache STALE/HIT/BYPASS/EXPIRED
   - Política diferenciada por status (403→cooldown directo 8-15min, 429→backoff exp, 5xx→retry corto)
3. Escribir `net-shield/nginx/iptv-shield-rate.conf` con:
   - `map $request_uri $shield_upstream_host`
   - `limit_req_zone $shield_upstream_host zone=hard_cap:10m rate={DERIVED}r/s` (rate derivado de Fase A)
4. Escribir `net-shield/nginx/lua_dump_endpoint.conf` (introspección via /_lua_dump localhost-only)

### B.2 Aplicar al VPS

1. Backup pre-Fase-B: `/root/backups/full_pre_phaseB_<TS>/`
2. SCP los 4 archivos al VPS
3. Mover deprecated:
   - `iptv-stealth-rate.conf → .deprecated_<TS>`
4. Patchear `shield-location.conf` via python:
   - Quitar bloque `limit_conn stealth_upstream_conn 4`
   - Cambiar `limit_req zone=stealth_upstream_req` → `zone=hard_cap`
   - Cambiar `burst=15 delay=10` → `burst=100 nodelay`
5. Verificar rate-zone original `stealth_upstream_req` ya no se referencia (sino fail nginx-t)
6. `nginx -t` — si falla rollback inmediato
7. **`systemctl restart nginx`** (NO reload)
8. Esperar 2s, verificar `systemctl is-active`
9. Verificar workers respawned (etime nuevo)
10. Verificar Lua loaded: `nginx -T | grep -E 'access_by_lua|header_filter_by_lua|hard_cap'`

### B.3 Smoke + validación inmediata

1. Curl HTTPS sintético con auth válido + path inválido → expect upstream 4xx
2. Verificar respuesta tiene header `X-APE-Circuit: backoff` → confirma Lua fire post-restart
3. Verificar log `[APE-CIRCUIT] host=<upstream-real>` (NO `iptv-ape.duckdns.org`)
4. Esperar 60s, verificar:
   - 0 trips de `hard_cap` en error log (rate=20+ no debe disparar con tráfico normal)
   - X-APE-Circuit headers visibles en tráfico real

**Criterio go/no-go**: si Lua sigue silente post-restart → STOP, investigar (`lua_code_cache off`, version mismatch, etc). Si hard_cap dispara >10/min → STOP, rate calibrado mal.

### B.4 Rollback ready

```bash
# Si algo falla en B.2/B.3:
mv /etc/nginx/conf.d/iptv-stealth-rate.conf.deprecated_<TS> iptv-stealth-rate.conf
cp /etc/nginx/snippets/shield-location.conf.bak_pre_phaseB_<TS> /etc/nginx/snippets/shield-location.conf
nginx -t && systemctl restart nginx
```

## Fase C — Autopilot v2 observe (~5 min, sin mutación productiva)

1. Escribir `net-shield/autopilot/netshield_autopilot_v2.py` localmente con fixes:
   - Excluir `ut=-` y STALE/HIT al medir (H6)
   - `STABILITY_WINDOWS=288` (H8 — coincide con doc 24h)
   - `MAX_RATE=100` (H9 subido)
   - Glob log files con rotated (H10)
   - Cap `burst ≤ rate × 10` (H9)
2. SCP a `/opt/netshield/autopilot/`
3. Crear systemd service + timer en MODO `observe` (5min cycle)
4. `systemctl daemon-reload + enable --now netshield-autopilot.timer`
5. Trigger manual primer run: `systemctl start netshield-autopilot.service`
6. Verificar:
   - State file creado en `/opt/netshield/autopilot/state/history.jsonl`
   - JSON output con métricas reales
   - `journalctl -u netshield-autopilot.service` sin errores

## Fase D — Memoria + cierre (~3 min)

1. Update `reference_phase35_lua_DEPLOYED.md` → estado v3 con fix STALE
2. New `reference_autopilot_v2_observe_deployed.md`
3. Update `feedback_phase35_doctrine.md` con las 12 leyes operativas
4. Update `feedback_vanilla_rate_too_blunt.md` con la solución (hard cap permisivo + Lua reactive)
5. Update `MEMORY.md` index

## Critical files

| Path | Acción |
|---|---|
| `/etc/nginx/sites-enabled/iptv-stealth` | mv to disabled (Fase A) |
| `/etc/nginx/conf.d/iptv-stealth-rate.conf` | rename to .deprecated (Fase B) |
| `/etc/nginx/conf.d/iptv-shield-rate.conf` | NEW (Fase B) |
| `/etc/nginx/snippets/shield-location.conf` | patch (Fase B) |
| `/etc/nginx/lua/upstream_gate.lua` | unchanged (already v2 correct) |
| `/etc/nginx/lua/upstream_response.lua` | UPDATE to v3 con STALE fix |
| `/etc/nginx/conf.d/iptv-lua-circuit.conf` | unchanged (lua_shared_dict already declared) |
| `/etc/nginx/conf.d/lua-dump-endpoint.conf` | NEW (introspección) |
| `/opt/netshield/autopilot/netshield_autopilot_v2.py` | NEW |
| `/etc/systemd/system/netshield-autopilot.service` | NEW |
| `/etc/systemd/system/netshield-autopilot.timer` | NEW |

## Verification end-to-end

1. Post-Fase-A: rate recomendado tiene sentido vs tráfico observado
2. Post-Fase-B: Lua dispara visible en headers + logs `[APE-CIRCUIT] host=<upstream-real>`
3. Post-Fase-B: hard_cap NO dispara con tráfico normal (<5/min)
4. Post-Fase-B: zapping TTFB <200ms preservado
5. Post-Fase-C: autopilot timer scheduled, primera ejecución sin error, state file con métricas
6. Post-Fase-D: memoria persistida, MEMORY.md actualizado

## Riesgos + mitigación

| Riesgo | Mitigación |
|---|---|
| Restart falla, nginx no levanta | Rollback de shield-location desde backup, restart de nuevo |
| Lua silente también post-restart | Hipótesis #2: `lua_code_cache off` + reload, ver si carga. Si tampoco → migrar a `*_by_lua_block` inline |
| hard_cap dispara mucho post-deploy | Subir rate +50% en Fase B retry. Calibración inicial puede ser conservadora |
| Cache STALE protege errores reales upstream | Aceptable temporalmente — Lua skip STALE es correcto. Si STALE sostenido >70% → upstream caído, atender separadamente |
| Autopilot interpreta logs mal | Modo observe no muta. Si métricas absurdas → fix script, no afecta producción |
