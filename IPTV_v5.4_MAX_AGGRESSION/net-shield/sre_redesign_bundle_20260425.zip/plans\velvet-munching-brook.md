# Plan — Medición 24-72h Fase 3.5 Vanilla, Go/No-Go a Phase 2 Lua

## Context

Sub-proyecto A (frontend STEALTH JS) y Sub-proyecto B (NGINX vanilla rate governance) ambos desplegados el 2026-04-25 ~08:45 UTC. Baseline T0 capturada en `/root/netshield-metrics/baseline_20260425_090300.json` (7441 req/24h en logs, 0 trips de mi `limit_req`, load avg 0.36).

Antes de proceder a Phase 2 (OpenResty/Lua state machine — instalación de OpenResty reemplaza nginx vanilla, blast radius alto) necesitamos **datos reales 24-72h** que respondan: ¿bajan los 403/429 desde upstream sin generar regresiones?

Hallazgo crítico al leer `Mejora+ LMM.txt`: **el sistema Sentinel ya está desplegado** (`/opt/netshield/bin/sentinel-collect.sh|classify.py|diagnose.py|execute.py|report.py` + systemd timer 1h + PHP endpoint + frontend widget). Tiene 13 firmas conocidas en KB rule-based (`iptv_403`, `iptv_5xx`, `iptv_slow_response`, `wg_peer_stale`, `cache_warmer_fail`, etc) y publica snapshot JSON en `/dev/shm/netshield_sentinel.json`. **Reutilizo Sentinel como source-of-truth de la medición**, no construyo tooling nuevo.

## Goal

Decidir Go/No-Go a Phase 2 Lua tras 72h de observación, con criterios objetivos basados en lifetime_counts de Sentinel + métricas de logs nginx.

## Métricas a capturar

| Métrica | Fuente | Baseline T0 | Objetivo |
|---|---|---|---|
| `iptv_403` lifetime count | `sentinel-report.py` → `/dev/shm/netshield_sentinel.json` | a capturar | ↓ ≥30% en 24h |
| `iptv_5xx` lifetime count | mismo | a capturar | sin aumento (regresión) |
| `iptv_slow_response` lifetime count | mismo | a capturar | sin aumento (TTFB regresión) |
| 429 emitidos por shield (mi rate) | `grep 'limiting requests.*stealth_upstream_req' /var/log/nginx/error.log` | 0 (post-deploy) | <5/h |
| 429 conn (mi limit_conn) | `grep 'limiting connections.*stealth_upstream_conn' error.log` | 0 | <5/h |
| Avg rt 200/206 | `awk` sobre shield_access.log | a capturar | sin degradación |
| WG transfer | `wg show wg0 transfer` | 69.7+23.7 GB TX | sigue creciendo |
| `wg_peer_stale` | Sentinel | a capturar | 0 |

## Approach

**T0 (ahora)**: capturar baseline completo del estado Sentinel + nginx logs.

**Cada checkpoint (T+1h, T+24h, T+48h, T+72h)**: snapshot del JSON Sentinel + counts agregados + diff vs anterior.

**Critical files (VPS, sin modificar — solo lectura)**:
- `/opt/netshield/state/signatures.json` — lifetime_counts y last_run
- `/opt/netshield/state/proposals_index.json` — propuestas Sentinel pendientes
- `/dev/shm/netshield_sentinel.json` — snapshot publicado
- `/var/log/nginx/error.log` — limit_req/limit_conn trips
- `/var/log/nginx/shield_access.log` — status code distribution

**Critical files (local, nuevos para registro de snapshots)**:
- `IPTV_v5.4_MAX_AGGRESSION/net-shield/metrics/baseline_t0_20260425.json` — baseline
- `IPTV_v5.4_MAX_AGGRESSION/net-shield/metrics/snapshot_T+{1h,24h,48h,72h}.json` — checkpoints
- `IPTV_v5.4_MAX_AGGRESSION/net-shield/metrics/decision_72h.md` — Go/No-Go report final

## Schedule

| Checkpoint | Acción | Salida |
|---|---|---|
| T+0 (ahora) | Baseline Sentinel + nginx counts | `baseline_t0_20260425.json` |
| T+1h | Smoke check: 0 regresiones, tráfico fluyendo | `snapshot_T+1h.json` |
| T+24h | Primera comparación significativa vs T0 | `snapshot_T+24h.json` + delta |
| T+48h | Confirmación tendencia | `snapshot_T+48h.json` |
| T+72h | Decisión Go/No-Go | `decision_72h.md` |

## Decision Criteria (T+72h)

| Estado | Condiciones | Acción |
|---|---|---|
| 🟢 GREEN | ↓ iptv_403 ≥30% **AND** 0 nuevas regresiones (5xx, slow) **AND** <5/h × 429 propios | Brainstorm Phase 2 OpenResty/Lua con runbook |
| 🟡 YELLOW | ↓ iptv_403 <30% **AND** 0 regresiones | Tune: subir rate a 5r/s o burst a 25, observar otras 24h |
| 🔴 RED | nuevas regresiones (5xx, TTFB) **OR** >20/h × 429 propios | Rollback inmediato (`shield-location.conf.bak_pre_*`), repensar |

## Reuse de Sentinel (no rebuild)

Existing helpers en VPS que se reusan tal cual:
- `sentinel-collect.sh` (1h cycle) ya barre logs y clasifica
- `sentinel-classify.py` con 13 firmas KB (`/opt/netshield/state/signatures.json`)
- `sentinel-report.py` ya genera `/dev/shm/netshield_sentinel.json`
- PHP endpoint `/api/netshield-sentinel.php` accesible vía frontend si quieres ver dashboard

Mi script de captura es trivial: `cat /dev/shm/netshield_sentinel.json` + `awk` sobre logs + persistir local.

## Out of scope (rastreable a futuro)

- **Phase 2 Lua**: condicionado a GREEN en T+72h. Spec ya guardada en `net-shield/nginx/lua/upstream_*.lua` y `openresty-future-integration.conf`.
- **Multi-VPS HA (Fase 4 reframed)**: no IP rotation. Failover técnico solo. Espera GREEN de Phase 2.

## Verification end-to-end

1. **T+0**: ejecuta script de baseline, confirma JSON parsea con counts existentes para las 13 firmas
2. **T+1h**: smoke check — `nginx active`, 0 nuevas regresiones críticas, tráfico WG fluye
3. **T+24h**: snapshot comparativo. Si iptv_403 sube en lugar de bajar → bandera roja, investigar por qué (config errónea? caso edge no contemplado?)
4. **T+72h**: decisión documentada en `decision_72h.md` con datos, no opiniones.

## Riesgos

| Riesgo | Mitigación |
|---|---|
| Sentinel timer no corre o no clasifica | Verificar en T+1h que `signatures.json` tiene `last_run` reciente. Si no, troubleshoot Sentinel antes de seguir midiendo. |
| Tráfico bajo durante 72h (poca señal) | 7441 req/24h baseline es suficiente. Si baja >50% (vacaciones, ONN apagado), extender ventana. |
| Falso positivo "GREEN" si provider IPTV no está blockeando ahora | Validar contra histórico Sentinel (`lifetime_counts`) — si ya antes 403 estaba bajo, el delta no es atribuible a mi cambio. |
